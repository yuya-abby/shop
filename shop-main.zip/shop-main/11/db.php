<?php
$link=mysqli_connect("127.0.0.1","root","","shop");
mysqli_query($link,"set charset utf8");
session_start();
?>