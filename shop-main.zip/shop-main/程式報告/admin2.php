<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理員2</title>
</head>
<body>
    

<?php
include ("db.php");

if (!isset($_SESSION['mid'])) {
    header("Location: a-admin.php");
    exit;
}

//session 值: [mid]
$mid = $_SESSION['mid'];

//判斷 session值是否有在admer資料表內(確認是否是管理員)
$sql = "SELECT * FROM admer WHERE id = '" . $mid . "'";
$res=mysqli_query($link,$sql);
//有符合的筆數>=1....是管理員
if(mysqli_num_rows($res)>0){
    //是管理員
    //程式往下走，捉取會員資料
}
else
{
    //不是管理員
    header("Location: a-admin.php");
    exit;
}

?>

<div style="background-color:green; height:200px; font-size:30px;">管理員權限</div>
<br>

<div>網站會員</div>
<div>
<table border="1">
        <tr><td>accound</td><td>email</td><td>name</td><td>password</td><td>phone</td><td>type</td></tr>
        <?php

$sql2 = "SELECT * FROM user";
$res2=mysqli_query($link,$sql2);
if(mysqli_num_rows($res)>0){

    //有會員資料,顯示
    $num_rows = mysqli_num_rows($res2); //紀錄捉出來的資料表筆數
    for ($i = 0; $i <= $num_rows-1; $i++) {
        
        $row = mysqli_fetch_assoc($res2);
        $data_account = $row['account'];
        $data_email = $row['email'];
        $data_name = $row['name'];
        $data_password = $row['password'];
        $data_phone = $row['phone'];
        $data_type = $row['type'];
        echo "<tr><td>" . $data_account . "</td><td>" . $data_email . "</td><td>" . $data_name . "</td><td>" . $data_password  . "</td><td>" . $data_phone ."</td><td>" . $data_type ."</td></tr>";
    }
    
}
else
{
    echo "<tr><td colspan='6'>無資料</td></tr>";
}
            //<tr><td>A</td><td>B</td><td>C</td><td>D</td><td>E</td><td>F</td></tr>
        ?>
     
</table>
</div>


<!-- 留言 -->
<div style="margin-top:30px;">留言</div>
<div>
<table border="1">
        <tr><td>accound</td><td>email</td><td>name</td><td>password</td><td>phone</td><td>type</td></tr>
        <?php

$sql3 = "SELECT * FROM msg";
$res3=mysqli_query($link,$sql3);
if(mysqli_num_rows($res)>0){

    //有會員資料,顯示
    $num_rows = mysqli_num_rows($res3); //紀錄捉出來的資料表筆數
    for ($i = 0; $i <= $num_rows-1; $i++) {
        
        $row = mysqli_fetch_assoc($res3);
        $data_account = $row['account'];
        $data_title = $row['title'];
        $data_text = $row['text'];
        $data_img = $row['img'];
        $data_add_time = $row['add_time'];
        $data_up_time = $row['up_time'];
        echo "<tr><td>" . $data_account . "</td><td>" .  $data_title  . "</td><td>" . $data_text  . "</td><td>" .  $data_img  . "</td><td>" . $data_add_time ."</td><td>" . $data_up_time ."</td></tr>";
    }
    
}
else
{
    echo "<tr><td colspan='6'>無資料</td></tr>";
}
            //<tr><td>A</td><td>B</td><td>C</td><td>D</td><td>E</td><td>F</td></tr>
        ?>
     
</table>
</div>



<!-- 商品 -->









</body>
</html>
