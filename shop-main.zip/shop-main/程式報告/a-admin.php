<!DOCTYPE html>
<html >
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理員</title>

    <script type="text/javascript">
        function error_show()
        {
            alert("錯誤的帳號或密碼!")
        }     
    </script>

</head>
<body>

<?php

include ("db.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
   
   // if(isset($_POST['account']) && isset($_POST['password']) )
   if (!empty($_POST['account']) && !empty($_POST['password'])) 
   {
        //傳進來的值
        $account = $_POST['account'];
        $password = $_POST['password'];

        //資料庫判斷
      //  $sql="SELECT * FROM `admer` WHERE `account` ='$account' AND `password` = '$password'";
      $sql = "SELECT * FROM admer WHERE account = '" . $account . "' AND password = '" . $password . "'";
      
      $res=mysqli_query($link,$sql);


        //有符合的筆數>=1
        if(mysqli_num_rows($res)>0){

           // echo '<script type="text/javascript">alert("' . $row['id'] . '")</script>';
           
           $num_rows = mysqli_num_rows($res); //紀錄捉出來的資料表筆數
           for ($i = 0; $i <= $num_rows-1; $i++) {
               $row = mysqli_fetch_assoc($res);
         
               //echo '<script type="text/javascript">alert("' . $row['id'] . '")</script>';
               $_SESSION['mid']=$row['id'];
               header("location:admin2.php");
           }

        }
        else
        {
            echo '<script type="text/javascript">error_show()</script>';
        }




        
    }
    else
    {
       echo '<script type="text/javascript">error_show()</script>';
    }

}




?>




<!-- <table>
    <tr><td colspan="2"></td><</tr> 
    <tr><td></td><td></td><</tr> 
    <tr><td></td><td></td></tr> 
    <tr><td></td><td></td></tr> 
    </table> -->
    <form method="post" action="">
    <table  align="center" style="width:300px;" cellspacing="10" cellpadding="0" >
    <tr><td colspan="2"><h1 style="width:100%;text-align:center">管理員登入</h1><td></tr> 
    <tr><td style="width: 80px;">account:</td><td><input type="text" name="account" id="account" style="width:100%"></td></tr> 
    <tr><td style="width: 80px;">password:</td><td><input type="password" name="password" id="password" style="width:100%"></td></tr> 
    <tr><td colspan="2" align="right"><input type="submit" value="login" style="width:80px"></td></tr> 
    </table>
    </form>


</body>
</html>
